#if ((${PACKAGE_NAME} && ${PACKAGE_NAME} != ""))package ${PACKAGE_NAME} #end
#parse("File Header.java")
case class ${NAME}(
  uuid: UUID = UUID.randomUUID(),
)

object ${NAME} {
  implicit val format: Format[${NAME}] = Json.format[${NAME}]
}
