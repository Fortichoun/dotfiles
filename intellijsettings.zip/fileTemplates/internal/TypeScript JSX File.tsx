import React from 'react';

type Props = {
  defaultProp: string;
};

export const ${NAME}: React.FC<Props> = ({ defaultProp }) => {
  return <div>{defaultProp}</div>;
};
