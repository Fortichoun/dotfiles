export const ${NAME}: void = () => {
    return undefined;
}